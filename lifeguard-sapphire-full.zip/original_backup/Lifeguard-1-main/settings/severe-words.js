module.exports = [
    'nigga',
    'nigger',
    'negro',
];